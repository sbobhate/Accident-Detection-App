package com.example.jmago.caraccidentdetectorf2016;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;



public class Passremind extends Activity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_passremind);
    }
}
