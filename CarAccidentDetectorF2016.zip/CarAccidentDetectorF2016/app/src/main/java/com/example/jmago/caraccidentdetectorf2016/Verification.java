package com.example.jmago.caraccidentdetectorf2016;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;

public class Verification extends Activity implements View.OnClickListener{
    int index;
    EditText vc;
    Button pr,rs;
    String msgData,vcode,random,phoneNo;
    TextView timer;
    final Timer t=new Timer();
    TimerTask task;
    MyCounter counter=new MyCounter(121000,1000);
    private static final String FORMAT = "%02d:%02d";
    final Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.verification_main);
        vc=(EditText)findViewById(R.id.vc);
        pr=(Button)findViewById(R.id.pr);
        pr.setOnClickListener(this);
        rs=(Button)findViewById(R.id.rs);
        rs.setOnClickListener(this);
        Bundle b=getIntent().getExtras();
        vcode=b.getString("vcode");
        random=b.getString("random");
        phoneNo=b.getString("phoneNo");
        timer=(TextView)findViewById(R.id.timer);
        counter.start();
        startTimer();

    }

    public void startTimer() {
        initialiseTimerTask();
        t.schedule(task,0,2000);
    }

    private void initialiseTimerTask() {
        task=new TimerTask()
        {
            @Override
            public void run()
            {
                handler.post(new Runnable() {
                    public void run() {
                        Log.e("Debug", "Entered");
                        Cursor cursor = getContentResolver().query(Uri.parse("content://sms/inbox"), null, null, null, null);
                        cursor.moveToFirst();
                        for (int idx =0; idx <cursor.getColumnCount(); idx++)
                        {
                            msgData += "" + cursor.getColumnName(idx) + cursor.getString(idx);
                        }
                        if(msgData.contains(vcode))
                        {
                            t.cancel();
                            index = msgData.indexOf(vcode);
                            msgData = msgData.substring(index + 26, index + 26 + 6);
                            vc.setText(msgData);
                            pr.performClick();

                        }
                    }

                });

            }
        };
    }


    @Override
    public void onClick(View v) {
        if(v.getId()==R.id.pr) {
            String msg = vc.getText().toString();
            if (msg.equals(random)) {
                t.cancel();
                counter.cancel();
                Intent i = new Intent(this, HomeActivity.class);
                startActivity(i);
            } else {
                Toast.makeText(Verification.this, "Sorry,Incorrect code. Try again!", Toast.LENGTH_LONG).show();
            }
        }
        else if(v.getId()==R.id.rs)
        {
            try
            {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNo, null,vcode, null, null);
                Toast.makeText(getApplicationContext(), "Verification code sent ", Toast.LENGTH_SHORT).show();
            }
            catch (Exception e)
            {
                Toast.makeText(getApplicationContext(), "SMS failed, please try again.", Toast.LENGTH_LONG).show();
                e.printStackTrace();
            }
        }

    }
    public class MyCounter extends CountDownTimer {

        public MyCounter(long millisInFuture, long countDownInterval) {
            super(millisInFuture, countDownInterval);
        }

        @Override
        public void onFinish() {
            String msg=vc.getText().toString();
            if(msg.equals(""))
            {
                t.cancel();
                timer.setText("Click on resend to generate a verification code");
            }
            else
            {
                t.cancel();
                pr.performClick();
            }
        }

        @Override
        public void onTick(long millisUntilFinished) {
            timer.setText("Time left to fill the verification code: " + String.format(FORMAT,
                    TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished) - TimeUnit.HOURS.toMinutes(
                            TimeUnit.MILLISECONDS.toHours(millisUntilFinished)),
                    TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished) - TimeUnit.MINUTES.toSeconds(
                            TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished))));

        }
    }

}